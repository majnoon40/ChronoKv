# Repository Review — majnoon40/ChronoKv

**Reviewed:** 2026-10-05 · commit `8863bc8` (main, tag `v0.28.0` one commit earlier at `ced3806`)
**Method:** cloned, read the code and docs, built it, and ran the test suites and benchmark arena in a sandbox (2 vCPU Xeon @ 2.5 GHz, 1 GiB RAM, Linux 4.19 kernel with io_uring I/O ops blocked by seccomp, overlayfs). All results below are first-hand unless marked otherwise.

---

## Verdict

**ChronoKV is an embedded, multi-version (MVCC) key-value store with serializable (SSI) transactions, written as a single C++20 header (~13.2k lines) with a ~14.3k-line test suite as its only other source file.** MIT-licensed, Linux-only, zero dependencies.

This is one of the most disciplined hobby-scale systems codebases I have reviewed. The verification culture — adversarial audits published in-tree, every fix born fail-first with a regression test, deterministic-scheduler and serializability checkers with mutation proofs, crash fuzzing with reachability assertions — is stronger than most production database teams manage. The code I read is careful, the failure-path engineering is exceptional, and everything I ran passed.

It is **not production-ready**, and the project knows it: the B+ tree never reclaims pages (monotonic 256 MiB memory ceiling), new-key inserts serialize on one global mutex, power-loss testing is an admitted gap, and the whole thing is one translation unit that OOMs a 1 GiB compiler. The roadmap is honest about every one of these.

| Dimension | Rating | Notes |
|---|---|---|
| Correctness engineering | ★★★★★ | Audit → fail-first remediation loop; 505/505 tests pass here |
| Code quality (readability, comments) | ★★★★☆ | Comments carry real forensic history; some drift and extreme verbosity |
| Architecture | ★★★☆☆ | Sound WAL/durability core; tree & GC have acknowledged ceilings |
| Test infrastructure | ★★★★★ | DST, lincheck w/ mutations, crash-fuzz w/ reachability, per-fault coverage |
| Performance / scalability | ★★☆☆☆ | ~30–40k durable writes/s even before the weak-sandbox discount; global insert lock |
| Documentation | ★★★★☆ | Unusually honest; also unusually long |
| Production readiness | ★★☆☆☆ | By the project's own (accurate) assessment |
| Project sustainability | ★★☆☆☆ | One human maintainer + an AI review bot; all process discipline, no second human |

---

## 1. What the repo contains

```
chronokv.hpp        13,178 lines — the entire engine + public API
main.cpp            14,250 lines — the entire test suite (only file compiled)
Makefile               188 lines — build matrix (release/asan/tsan/stress/coverage/smoke/arena)
bench/                 arena.cpp + baselines.cpp (SQLite/LMDB/RocksDB adapters) + READMEs
docs/                  CHANGELOG, ROADMAP (v29→v30), request.txt (the audit prompt),
                       audits/ (2026-09-23 full adversarial audit, 2026-09-24 remediation spec)
scripts/               fault_coverage.py (gcov error-path coverage analyzer)
.github/workflows/     ci.yml — 8 job groups incl. nightly arena ledger
```

Engine components (marked `[SECTION_*]` in the header): CRC/IO primitives with fault injection; WAL record framing; a raw-syscall io_uring wrapper; `WalSegments` (segmented 64 MiB WAL, group commit, MANIFEST, recovery); `PublicationTracker` (strict-serializability barrier); `PhantomTracker` (SSI phantom detection); MVCC version chains with epoch-pinned GC; the `ChronoKV` core (transactions, checkpoint, delta/rebase checkpoint chain, backup, PITR); public `Database`/`Transaction`/`Batch`/observer/stream/async API; `PagePool` + `BTree` (4 KiB pages, per-page latches, OLC-style fences, hazard-pointer slots).

## 2. How it is developed (unusual, and central to the review)

- 92 commits, repo history starting ~Sep 17 2026; **49 of the 50 I cloned are authored by "ChronoKV Review Bot" (`qwen-review@users.noreply.github.com`)**, one by the human owner. This is an AI-driven development loop.
- `docs/request.txt` is the standing adversarial-audit prompt ("treat the implementation as the source of truth… do not assume comments or tests are correct").
- The Sep 23 audit found **21 defects (3 Critical, 4 High, 6 Medium, rest Low/docs)** — including a 61 KB heap overflow reachable from one legal `put` (CKV-001) and a transient-`bad_alloc` → corrupted-checkpoint → total-data-loss chain (CKV-003). Verdict: "not production-safe today."
- The Sep 24 remediation spec planned 5 waves / 20 commits; **all shipped as 0.28.0**, each with a fail-first regression test (`CKV_ONLY_REMEDIATION=1`). I spot-verified the CKV-001 fix (a `TREE_MAX_KEY_BYTES = 4048` gate in `commit_txn` + `PageCapacityError` guards + `static_assert`s pinning the derivation) and the CKV-005 sentinel-scan fix (`tree_scan_all`).
- The current arc (v29 M1) builds a benchmark arena with methodology-tagged output and baseline adapters for SQLite/LMDB/RocksDB under identical geometry, seeds, and durability-class mapping, gated "informational until one calibrated green week."

Whatever one thinks of AI-authored commits, the *process* here — published audits, fail-first tests, anti-vacuity checks, evidence-based flake classification — is better than what most human teams do. The caveat is that there is no second human in the loop; the safety net is process discipline, not reviewer judgment.

## 3. What I verified first-hand

Environment caveat: 2 weak cores, 1 GiB RAM, kernel 4.19 (no COOP_TASKRUN, io_uring I/O ops blocked → sync pwrite fallback everywhere), overlayfs. Numbers are floors, not representative.

| Check | Result |
|---|---|
| `make release` (`-O1`) | Clean build, **zero warnings**, 38 s |
| Full test suite (hooks-on) | **505 PASS / 0 FAIL**, exit 0, 6 min wall |
| Crash fuzz (in-suite) | 312 iterations, 161 armed crash points reached, **0 violations**; "every crash point is reachable: PASS" |
| Remediation battery | All CKV-001…021 regression tests PASS (1.3 s) |
| Hooks-OFF public-API smoke (the real consumer build) | All PASS |
| DST harness (stress build @ `-O0`) | 3 scenarios × 20 seeds, fork-isolated, all PASS (7 s) |
| Lincheck (strict-serializability checker) | PASS, including **8 mutation tests** proving the checker flags dropped/duplicated/reordered history — anti-vacuity by construction |
| Arena benchmark (group durability, 200k keys, 100 B values, 4 threads) | fillseq 30.1k ops/s · fillrandom 39.5k · readrandom 130k · ycsb_a ~40k reads + ~40k updates/s; prints an honest methodology header (kernel, CPUs, RAM, build flags, seed, "backing fs not classified" caveat) |
| io_uring runtime degradation | Probe correctly detected blocked I/O ops and fell back to offset-pinned pwrite — the v28 review-F1 fix working live |
| ASan build in 1 GiB | **Fails — cc1plus OOM even at `-O0`.** Corroborates the repo's own documented build-memory ceiling (the bot hit the identical wall; the latest commit message records it) |
| GitHub CI status | green on the head commit (per the repo page) |

The suite's closing diagnostics show the fault injection genuinely fires (write_fails, fsync_fails, truncations, async_committed_then_lost, torn tails, CRC fails, PITR filtering) rather than passing vacuously.

## 4. Code-quality assessment

**Strengths (specific):**

- **Failure-path engineering is the standout.** Fail-stop latches are consistent and layered: WAL `failed_` (D3), index `index_failed_` (D4 — a diverged tree can never reach a checkpoint that would truncate the WAL holding the truth), reservation-throw latch (CKV-012R — no higher cts is ever written past a frameless hole). The rollback-truncation gate keys on the *failure stage* via an atomically-published `written` flag, not the durability class — exactly the right discrimination for the async silent-loss contract (CKV-004). The truncation itself is fsynced so a power loss can't resurrect the failed batch (D2).
- **The group-commit leader/follower machinery** (H3 fix) uses a FIFO of batches with a documented invariant (`cur_batch_ == pending_.back()`, leaders drain front-first), so no batch can be orphaned and cts order matches WAL order. The lock-ordering note in `group_append` (batch_mu_ → pub leaf mutex, acyclic) is the kind of comment most codebases lack.
- **Comments carry forensic history**: past bugs (C1 leader hang, H3 mixed-durability segfault, v25.7 manifest-brick, SQLite WAL-snapshot trap in the baseline adapter) are documented with mechanism and repro at the site of the fix. This is archaeology-grade maintainability.
- **Raw-memory code is bounded**: WAL parsing uses a `need()` bounds lambda throughout; segment filenames parse strictly (`wal_%06llu.log`, exactly 6 digits); page layout is `#pragma pack`ed with `static_assert` tripwires; serialization is manual little-endian (endian-portable); io_uring ABI constants are spelled out for old distro headers.
- **Honest semantics documentation.** The `DurabilityMode` block states outright that Sync and Group are the *same mechanism*, and that Async's silent-loss-on-fsync-failure is a deliberate, counted (`async_committed_then_lost`) contract. The README's Known Limitations section admits the page-pool ceiling, the O(N²/256) GC sweep rescan, the observer-reentrancy deadlock, and that crash-fuzzing ≠ power-loss testing.

**Weaknesses:**

- **One translation unit (~27.5k lines)** — builds need >1 GiB RSS at `-O2`; sanitizer builds are impossible in 1 GiB (verified). The repo flags this as "the strongest argument for the v30 M5 source-split/amalgamation plan." It also makes the test suite a single 14k-line `main()` (mitigated by `CKV_ONLY_*` gates, but no real test framework or per-test binary).
- **Comment drift exists despite the culture**: lines 6328 and 10490 still say `TREE_MAX_KEY_BYTES (4044)` while the constant is 4048 — and line 2152 *documents* that the audit's 4044 came from a wrong 12-byte `LeafSlot`. Two stale mentions survive in a repo whose CKV-017/021 fixes were literally "doc truth." (The only new defect I found today; trivial.)
- **Verbosity as a tax**: ~1,300 lines of version-history commentary precede the first line of code in the header; commit messages run 40+ lines. Great for auditability, heavy for a "drop-in header" and for any new contributor's reading cost.
- Cosmetic: mixed indentation depths in `commit_txn` (4- vs 5-space blocks), a stray `#if 1` block, LICENSE year 2025 vs 2026 activity.

## 5. Architecture-level concerns (ranked)

1. **No B+ tree page reclamation** (documented). `PagePool::free()` has no callers; splits only add pages; delete-heavy workloads never get space back; pool exhaustion throws `bad_alloc`. This is a hard functional ceiling for long-lived databases — the roadmap's "credibility gap," slated for v29/v30.
2. **New-key insert serialization.** `nm_` (one global `shared_mutex`) guards the check-then-insert slow path *and* the tree put for every new key. The arena itself labels fillseq/fillrandom "nm_-path isolation workloads." Multi-writer insert scalability is structurally capped until the v29 writer-thread rewrite.
3. **Power-loss semantics untested.** Crash fuzz uses `_exit()`, which keeps the page cache — acknowledged. The v29 plan (fault-injecting block layer / dm-flakey) is the right next step; until then, the fsync-ordering claims rest on code reading and the io_uring chain construction, not observed power cuts.
4. **GC sweep cost O(N²/256)** per full sweep at large N (documented; persistent-cursor follow-up tracked).
5. **`~Transaction()` on an active transaction calls `std::abort()`.** Deliberate and documented, but an exception escaping a scope holding a `Transaction` SIGABRTs during unwinding — a genuine landmine for idiomatic C++ users expecting RAII rollback. Worth re-examining before 1.0.
6. **PITR mid-window**: an `as_of` between checkpoint boundaries is refused loudly once the covering WAL is rotated away (conservative, correct choice; capability recovery via multi-version deltas is tracked as future work).
7. **Single-process only** (flock guard), Linux-only. Fine for the niche, but stated plainly.

## 6. Benchmark credibility

The arena (v29 M1, in progress) does the right things: hooks-off consumer build, fixed calibration geometry, seed and methodology header on every TSV, durability-class mapping so cross-class comparisons can't be implied, baseline adapters that found and fixed three *fairness* bugs (LMDB dbi priming, RocksDB parent-dir creation, the SQLite WAL read-snapshot/SQLITE_BUSY trap). The nightly ledger job is deliberately informational until a calibrated green week. There are **no published performance claims yet** — consistent with the "measure before predict" rule. My sandbox numbers (30–40k durable writes/s on 2 weak cores with blocked io_uring) are floors; the honest read is that ChronoKV is not yet in incumbents' throughput league, which the roadmap concedes.

## 7. Recommendations

**For the maintainer (priority order):**
1. **Split the translation unit earlier than v30 M5.** The 1 GiB build wall is already blocking sanitizer runs in constrained environments (mine and the bot's). Even a `chronokv_impl.inc`-style split with an amalgamation script would unblock ASan/TSan locally.
2. Land the **page reclamation / tree merge** work before adding any new features — it is the binding constraint on real use.
3. Get **dm-flakey (or equivalent) power-loss testing** into CI in v29 M2 as planned; it is the largest remaining gap between claims and evidence.
4. Fix the two stale `4044` comments (lines ~6328, ~10490) — one-line change, keeps the "doc truth" bar honest.
5. Reconsider **`~Transaction()` → `abort()`**; auto-rollback-with-loud-log or a compile-time opt-in would remove the landmine without weakening guarantees.
6. Trim the header's leading ~1,300-line version-history block into `docs/` (the CHANGELOG exists now); keep the forensic comments at code sites, where they belong.
7. Consider a **human review checkpoint** per release tag, even a lightweight one — the process is machine-checked, but provenance currently rests entirely on a bot's self-reports.

**For a potential user:** treat 0.28.0 as a high-quality evaluation artifact, not a dependency. It is compelling if you need serializable transactions + PITR in a single header and your dataset fits a bounded page budget; it is not yet suitable where memory reclamation, insert scalability, multi-process access, non-Linux platforms, or verified power-loss behavior matter.

---

### Appendix — verification log (sandbox, 2026-10-05)

- `make release RELEASE_FLAGS="-O1"` → clean, 38 s, no warnings (g++ 12.2, Debian).
- `./build/release/test` → `ChronoKV 0.28.0 - ALL TESTS PASSED`, 505 PASS / 0 FAIL, 6m01s. Diagnostics: wal fsyncs=725,990, write_fails/fsync_fails/truncations non-zero (fault injection exercised), recovery torn_tails=1 crc_fails=2 dups=16 gaps=0.
- `CKV_ONLY_REMEDIATION=1` → PASS (1.3 s). `CKV_ONLY_LINCHECK=1 CKV_LINCHECK_SEEDS=5` → PASS incl. all 8 mutation detectors.
- `make stress STRESS_FLAGS="-O0 -DCHRONOKV_STRESS"` + `CKV_ONLY_DST=1 CKV_DST_SEEDS=20` → 3/3 scenarios PASS (fork-isolated; `-O1` stress OOMs this box, as documented).
- Hooks-off smoke (`CKV_IOURING_DISABLED` and native) → ALL PUBLIC-API SMOKE TESTS PASSED.
- `make arena ARENA_FLAGS="-O1"` + run → methodology header + TSVs as quoted above.
- `make asan` at `-O0` → cc1plus OOM at ~1.1 GiB total RSS (environment limit, matches repo documentation).
- io_uring banner: `setup OK / I/O ops BLOCKED → sync pwrite fallback` — runtime degradation path confirmed live.
