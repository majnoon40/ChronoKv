
    // =====================================================================
    // v29 M2 item 2 — DESIGN-FIRST scenarios (S5-S7): the DST plan grammar
    // grows the merge/rebalance/cascade and reclamation-retirement windows
    // BEFORE that code exists. M3 (page reclamation) and M4 (leaf merge /
    // rebalance) are unimplemented: PagePool::free() has no engine callers,
    // is_hazardous() has none at all, erase_recursive removes a slot and
    // returns — no underflow check, no borrow, no coalesce, no root
    // collapse, and the pages of an emptied leaf are retained forever.
    //
    // These scenarios are written against the DESIGN (roadmap M3/M4 and the
    // code's own forward references — Cursor::enter_leaf publishes its
    // hazard pointer "important for future merge/rebalance") and this item's
    // acceptance is the other half of the deal: they run GREEN against the
    // current merge-free tree. That works because every assertion below is
    // an invariant that must hold in BOTH regimes:
    //
    //   * exact differential-vs-std::map at quiesce — M4's own acceptance
    //     words ("the differential-vs-std::map test passes with merges
    //     active"); legal under concurrency because each key has exactly ONE
    //     owner thread, so the final state is a function of that owner's
    //     script, not of the interleaving;
    //   * observed-value legitimacy mid-flight — a freed-and-reused page read
    //     through a stale fence, or a version reclaimed under a live pin,
    //     surfaces as a foreign/garbage value, not as clean emptiness;
    //   * the page-pool accounting identity live+free == allocated/PAGE_SIZE
    //     — trivially true while free() has no callers, and the
    //     double-free/lost-page net from the moment M3 wires it;
    //   * hazard-pointer registry bounded by peak cursor concurrency, and
    //     zero slots in use at quiesce — M3's reuse admission
    //     (is_hazardous() finally gets its consumers) is only sound if slots
    //     are actually returned;
    //   * the CKV-008 mutation-epoch fence contract, asserted
    //     DETERMINISTICALLY at quiesce: mutating a leaf must change that
    //     leaf's fence. A merge mutates two leaves and an interior node; one
    //     that forgets the epoch bump is invisible to a concurrent cursor's
    //     fence re-check, which is exactly the class this pins;
    //   * the epoch reclaimer's admission rule under a live pin (S7):
    //     retirements made while a reader is pinned must stay PENDING, and
    //     must be reclaimed once the pin is gone. M3 retires pages through
    //     this same reclaimer (or through generation-tagged ids, per the HP4
    //     decision) — the rule is the design's, and it is real executed code
    //     today for version nodes.
    //
    // What is deliberately NOT asserted, and is instead RECORDED: the page
    // high-water mark. Today it ratchets — that is the README's known
    // limitation #1, and freezing it into an assertion would make the suite
    // fail the moment M3 fixes it. S6 records the numbers (CKV_DST_REPORT=1)
    // so M3/M4's acceptance ("the high-water mark stabilizes instead of
    // ratcheting", invariant P1) converts a recorded baseline into a gate.
    //
    // INSTRUMENTATION CONTRACT — the "plan grammar" half. Each scenario
    // gates on the census counts of windows that exist today, so a schedule
    // that never reaches them cannot pass (op counts alone cannot
    // distinguish "explored the window" from "never got there"). The windows
    // M3/M4 MUST instrument with stress_point() are named here, so the
    // coverage is a contract rather than a hope; today their census counts
    // are zero and are reported as PENDING. When the implementation lands,
    // its acceptance requires these same counters to be non-zero on these
    // scenarios — i.e. the seeded schedule provably entered the new windows:
    //
    //   M4 (leaf merge / rebalance), all on the erase_recursive delete path:
    //     tree_underflow_detected      key_count fell below the merge
    //                                  threshold — the borrow-vs-merge
    //                                  decision point
    //     tree_merge_sibling_latched   sibling latched (crabbing, exclusive)
    //     tree_merge_borrow            rebalance/rotate branch taken
    //     tree_merge_coalesce          merge branch taken
    //     tree_merge_interior_deleted  separator key removed from the parent
    //     tree_root_collapse           root collapsed, depth decreased
    //   M3 (page reclamation / reuse):
    //     page_retire_begin            freed page admitted to deferred
    //                                  retirement (epoch reclaimer or
    //                                  generation tag — the HP4 decision)
    //     page_retire_hp_blocked       retirement refused because
    //                                  is_hazardous() found a live pointer
    //     page_reuse_alloc             PagePool::alloc() popped a recycled
    //                                  id — the ABA window HP4 exists for
    // =====================================================================

    // Shared gate/report helper: the named-window census a scenario requires
    // (windows that exist today) and the design windows it reports as
    // pending until M3/M4 land. Returns false if a required window never
    // fired — a VACUOUS schedule, which is a scenario failure, not a pass.
    inline bool census_gate(const char* scn, dst::Progress* prog,
                            const std::vector<const char*>& required) {
        for (const char* nm : required) {
            if (dst::census_hits(prog, nm) == 0) {
                fprintf(stderr, "dst %s: VACUOUS schedule — window '%s' was never entered "
                                "(the scenario cannot claim coverage it did not exercise)\n",
                        scn, nm);
                return false;
            }
        }
        return true;
    }
    inline void census_report(const char* scn, dst::Progress* prog,
                              const std::vector<const char*>& design) {
        if (!getenv("CKV_DST_REPORT")) return;
        printf("      [%s] census: ops=%llu grants=%llu steals=%llu\n", scn,
               (unsigned long long)prog->ops.load(std::memory_order_relaxed),
               (unsigned long long)prog->grants.load(std::memory_order_relaxed),
               (unsigned long long)prog->timeouts.load(std::memory_order_relaxed));
        for (size_t i = 0; i < dst::kCensusSlots; ++i) {
            if (prog->census[i].name == nullptr) continue;
            printf("      [%s]   point %-32s hits=%llu\n", scn, prog->census[i].name,
                   (unsigned long long)prog->census[i].hits);
        }
        if (prog->census_overflow)
            printf("      [%s]   census overflow slots=%llu\n", scn,
                   (unsigned long long)prog->census_overflow);
        for (const char* nm : design)
            printf("      [%s]   DESIGN WINDOW %-28s hits=%llu  %s\n", scn, nm,
                   (unsigned long long)dst::census_hits(prog, nm),
                   dst::census_hits(prog, nm) ? "FIRED (implementation present)"
                                              : "pending (M3/M4 not implemented)");
    }
    inline const std::vector<const char*>& design_windows_m4() {
        static const std::vector<const char*> v = {
            "tree_underflow_detected", "tree_merge_sibling_latched", "tree_merge_borrow",
            "tree_merge_coalesce", "tree_merge_interior_deleted", "tree_root_collapse"};
        return v;
    }
    inline const std::vector<const char*>& design_windows_m3() {
        static const std::vector<const char*> v = {
            "page_retire_begin", "page_retire_hp_blocked", "page_reuse_alloc"};
        return v;
    }

    // S5 — leaf merge/rebalance window + hazard pointer vs page reuse
    // (M4/M3 design-first).
    //
    // Shape: three owner-writer threads on a key-partitioned keyspace (one
    // owner per key => the exact differential at quiesce is legal), two
    // short-lived full-range scanners, and ONE long-lived cursor that walks
    // the tree repeatedly across the whole churn. That last thread is the
    // point of the scenario: it keeps a published hazard pointer — and,
    // between steps, the leaf's shared latch — on pages the churn is
    // emptying, which are precisely the pages M4 will coalesce and M3 will
    // free and hand back out. Parking it there (bounded: each park can cost
    // one 5 ms steal window) hands the baton to a thread that wants to erase
    // into the very leaf the reader is holding, i.e. the merge window seen
    // from the reader's side.
    //
    // The workload is M3's own acceptance shape — delete-then-reinsert: a
    // stable core of keys updated in place, and a churning majority
    // inserted then deleted every round, so the same leaves are emptied and
    // refilled repeatedly. Today that ratchets the pool; M3's acceptance is
    // that it stops.
    inline int s5_merge_window(uint64_t seed, dst::Progress* prog, const std::string& wd) {
        (void)wd;   // tree-level scenario: no WAL, no filesystem
        using chronokv_page::PagePool;
        using chronokv_page::PAGE_SIZE;
        using chronokv_btree::BTree;
        PagePool pool(16ULL * 1024 * 1024);   // 4096 pages: bounded, no exhaustion
        BTree tree(pool);

        constexpr int NOWN = 3;        // owner-writer threads
        constexpr int NKEYS = 360;     // keyspace; owner t holds i % NOWN == t
        constexpr int ROUNDS = 3;      // val(i,ROUNDS) is the kept value
        constexpr int NSCAN = 20;      // full-range scans per scanner thread
        constexpr int NPASS = 5;       // long-lived-cursor walks of the tree
        constexpr int VALLEN = 72;     // ~42 entries/leaf => ~9 leaves, depth 2
        const std::string lo = "m0000", hi = "m9999";

        auto key = [](int i) {
            char b[8]; snprintf(b, sizeof b, "m%04d", i); return std::string(b);
        };
        auto val = [](int i, int r) {
            std::string v = "r" + std::to_string(r) + ":" + std::to_string(i) + ":";
            v.resize(VALLEN, '.');
            return v;
        };
        auto keep = [](int i) { return (i % 4) == 0; };   // never erased: updated in place
        auto legitimate = [&](const std::string& k, const std::string& v) {
            if (k.size() != 5 || k[0] != 'm') return false;
            const int i = atoi(k.c_str() + 1);
            if (i < 0 || i >= NKEYS || key(i) != k) return false;
            for (int r = 0; r <= ROUNDS; ++r) if (v == val(i, r)) return true;
            return false;
        };

        std::atomic<long> n_ins{0}, n_upd{0}, n_del{0}, n_del_miss{0}, n_throw{0};
        std::atomic<long> n_scans{0}, n_rows{0}, n_bad{0}, n_steps{0}, n_parks{0};
        dst::arm(seed, NOWN + 3, prog);

        std::vector<std::thread> owners;
        for (int t = 0; t < NOWN; ++t) owners.emplace_back([&, t] {
            dst::point("start");
            for (int r = 0; r <= ROUNDS; ++r) {
                for (int i = t; i < NKEYS; i += NOWN) {
                    dst::point("s5_put");
                    try {
                        if (tree.put(key(i), val(i, r))) n_ins.fetch_add(1, std::memory_order_relaxed);
                        else n_upd.fetch_add(1, std::memory_order_relaxed);
                    } catch (...) { n_throw.fetch_add(1, std::memory_order_relaxed); }
                    if (!keep(i)) {
                        dst::point("s5_del");
                        try {
                            // Same thread wrote it a moment ago and owns the
                            // key, so a miss is a real defect (or a broken
                            // script), not a race.
                            if (tree.erase(key(i))) n_del.fetch_add(1, std::memory_order_relaxed);
                            else n_del_miss.fetch_add(1, std::memory_order_relaxed);
                        } catch (...) { n_throw.fetch_add(1, std::memory_order_relaxed); }
                    }
                }
            }
            dst::thread_done();
        });
        auto scan_loop = [&] {
            dst::point("start");
            for (int n = 0; n < NSCAN; ++n) {
                dst::point("s5_scan");
                std::vector<std::pair<std::string, std::string>> rs;
                try { rs = tree.range_scan(lo, hi); }
                catch (...) { n_throw.fetch_add(1, std::memory_order_relaxed); break; }
                n_scans.fetch_add(1, std::memory_order_relaxed);
                for (auto& [k, v] : rs) {
                    n_rows.fetch_add(1, std::memory_order_relaxed);
                    // Mid-flight only LEGITIMACY is sound (per-page snapshot
                    // semantics: order/completeness are not guaranteed while
                    // writers run — README "Stream consistency"). Exactness
                    // is asserted at quiesce below.
                    if (!legitimate(k, v)) n_bad.fetch_add(1, std::memory_order_relaxed);
                }
            }
            dst::thread_done();
        };
        std::thread sc1(scan_loop), sc2(scan_loop);
        std::thread holder([&] {
            dst::point("start");
            try {
                for (int pass = 0; pass < NPASS; ++pass) {
                    BTree::Cursor c = tree.open_cursor(lo, hi);
                    while (c.valid()) {
                        if (!legitimate(c.key(), c.value()))
                            n_bad.fetch_add(1, std::memory_order_relaxed);
                        const long s = n_steps.fetch_add(1, std::memory_order_relaxed) + 1;
                        c.next();
                        // Bounded park with the cursor ON a leaf: HP
                        // published, shared latch held. Every park can cost
                        // one steal window, hence the cap.
                        if (s % 40 == 0 && n_parks.load(std::memory_order_relaxed) < 10) {
                            n_parks.fetch_add(1, std::memory_order_relaxed);
                            dst::point("s5_hold");
                        }
                    }
                }
            } catch (...) { n_throw.fetch_add(1, std::memory_order_relaxed); }
            dst::thread_done();
        });
        for (auto& t : owners) t.join();
        sc1.join(); sc2.join(); holder.join();
        dst::disarm();

        if (n_bad.load()) {
            fprintf(stderr, "dst S5: %ld illegitimate (key,value) observations — foreign or "
                            "garbage value (page reuse / reclaim aliasing)\n", n_bad.load());
            return 9;
        }
        if (n_throw.load()) {
            fprintf(stderr, "dst S5: %ld unexpected exceptions\n", n_throw.load());
            return 10;
        }
        if (n_del_miss.load()) {
            fprintf(stderr, "dst S5: %ld erases missed a key its own owner had just written\n",
                    n_del_miss.load());
            return 11;
        }
        // Non-vacuity: the workload must actually have happened.
        const int NCHURN = NKEYS - (NKEYS + 3) / 4;   // keys with keep() false
        if (n_ins.load() < NCHURN || n_upd.load() == 0 || n_del.load() < NCHURN ||
            n_scans.load() != 2 * NSCAN || n_rows.load() == 0 || n_steps.load() == 0) {
            fprintf(stderr, "dst S5: VACUOUS workload (ins=%ld upd=%ld del=%ld scans=%ld "
                            "rows=%ld cursor_steps=%ld)\n", n_ins.load(), n_upd.load(),
                    n_del.load(), n_scans.load(), n_rows.load(), n_steps.load());
            return 12;
        }
        // Exact differential at quiesce (M4's named acceptance shape).
        std::map<std::string, std::string> expect;
        for (int i = 0; i < NKEYS; ++i) if (keep(i)) expect[key(i)] = val(i, ROUNDS);
        std::vector<std::pair<std::string, std::string>> rs;
        try { rs = tree.range_scan(lo, hi); }
        catch (const std::exception& e) {
            fprintf(stderr, "dst S5: quiesced range_scan threw: %s\n", e.what());
            return 13;
        }
        if (rs.size() != expect.size()) {
            fprintf(stderr, "dst S5: quiesced scan returned %zu rows, differential oracle "
                            "expects %zu\n", rs.size(), expect.size());
            return 13;
        }
        for (size_t j = 0; j < rs.size(); ++j) {
            if (j > 0 && !(rs[j - 1].first < rs[j].first)) {
                fprintf(stderr, "dst S5: quiesced scan out of order / duplicated at row %zu "
                                "(%s then %s)\n", j, rs[j - 1].first.c_str(), rs[j].first.c_str());
                return 14;
            }
            auto it = expect.find(rs[j].first);
            if (it == expect.end() || it->second != rs[j].second) {
                fprintf(stderr, "dst S5: quiesced row %zu = (%s,%.12s) disagrees with the "
                                "differential oracle\n", j, rs[j].first.c_str(),
                        rs[j].second.c_str());
                return 13;
            }
        }
        // Point reads must agree with the leaf chain: a separator lost by a
        // merge hides a key from the SEARCH path while the leaf chain still
        // shows it (and vice versa).
        for (int i = 0; i < NKEYS; ++i) {
            std::string got;
            bool found = false;
            try { found = tree.get(key(i), &got); }
            catch (...) { fprintf(stderr, "dst S5: get(%s) threw\n", key(i).c_str()); return 10; }
            if (keep(i)) {
                if (!found || got != val(i, ROUNDS)) {
                    fprintf(stderr, "dst S5: point read of kept key %s: found=%d value=%.12s "
                                    "(expected %.12s)\n", key(i).c_str(), (int)found,
                            got.c_str(), val(i, ROUNDS).c_str());
                    return 15;
                }
            } else if (found) {
                fprintf(stderr, "dst S5: deleted key %s still readable (value %.12s)\n",
                        key(i).c_str(), got.c_str());
                return 15;
            }
        }
        // Page-pool accounting identity (the M3 double-free / lost-page net).
        const size_t pages = pool.allocated() / PAGE_SIZE;
        if (pool.live_count() + pool.free_count() != pages) {
            fprintf(stderr, "dst S5: pool accounting broken: live=%zu free=%zu allocated=%zu "
                            "pages (identity live+free==allocated)\n", pool.live_count(),
                    pool.free_count(), pages);
            return 16;
        }
        // Hazard-pointer registry: bounded by peak cursor concurrency, every
        // slot returned at quiesce.
        if (tree.hp_in_use_for_test() != 0 || tree.hp_slot_count_for_test() > 16) {
            fprintf(stderr, "dst S5: HP registry not quiesced/bounded: in_use=%zu slots=%zu\n",
                    tree.hp_in_use_for_test(), tree.hp_slot_count_for_test());
            return 17;
        }
        // CKV-008 mutation-epoch fence contract, deterministic at quiesce.
        {
            int probe = 0;
            while (probe < NKEYS && !keep(probe)) ++probe;
            const auto leaf = tree.find_leaf_for_test(key(probe));
            const auto f = tree.capture_leaf_fence_for_test(leaf);
            if (!tree.erase(key(probe))) {
                fprintf(stderr, "dst S5: fence-probe key %s vanished\n", key(probe).c_str());
                return 18;
            }
            if (tree.leaf_fence_unchanged_for_test(leaf, f)) {
                fprintf(stderr, "dst S5: erase on leaf %llu left its fence UNCHANGED — the "
                                "mutation epoch was not bumped, so a concurrent cursor's "
                                "fence re-check could not see it (a merge that forgets the "
                                "bump is this bug with two leaves)\n",
                        (unsigned long long)leaf);
                return 18;
            }
        }
        // Structural witness: interior levels must exist, or the merge /
        // cascade / interior-key-deletion windows have nothing to act on.
        if (tree.depth() < 2) {
            fprintf(stderr, "dst S5: tree depth %zu < 2 — no interior level, scenario vacuous\n",
                    tree.depth());
            return 19;
        }
        if (!census_gate("S5", prog, {"tree_leaf_latch_gap", "tree_split_begin",
                                      "tree_cursor_leaf_switch"}))
            return 20;
        census_report("S5", prog, design_windows_m4());
        if (getenv("CKV_DST_REPORT")) {
            printf("      [S5] witnesses: ins=%ld upd=%ld del=%ld scans=%ld rows=%ld "
                   "cursor_steps=%ld hp_parks=%ld\n", n_ins.load(), n_upd.load(), n_del.load(),
                   n_scans.load(), n_rows.load(), n_steps.load(), n_parks.load());
            printf("      [S5] pool: high_water_bytes=%zu pages=%zu live=%zu free=%zu "
                   "frag=%.3f  depth=%zu size=%zu  (RECORDED, not asserted: M3's acceptance "
                   "is that a delete-then-reinsert workload stops ratcheting this)\n",
                   pool.allocated(), pages, pool.live_count(), pool.free_count(),
                   pool.fragmentation_ratio(), tree.depth(), tree.size());
        }
        return 0;
    }

    // S6 — split/merge CASCADE across interior levels (M4 design-first) plus
    // the empty-tree extreme (root collapse) and the pool numbers P1 is
    // about (M3 design-first).
    //
    // Shape: an unarmed build phase grows a multi-level tree (depth >= 2 is
    // asserted, so the cascade has interior levels to cascade through), then
    // two RANGE-partitioned owners drain and refill contiguous blocks of the
    // keyspace while three scanners run. Contiguity is the point: emptying a
    // whole block empties whole leaves, which is what makes the post-M4
    // borrow-vs-merge decision, the interior separator deletion and (at the
    // end) the root collapse reachable at all. The last round leaves the
    // lower half of the keyspace empty and the upper half present, so the
    // quiesced differential is non-trivial in both directions; then a
    // deterministic single-threaded drain empties the tree completely — the
    // maximal cascade — and records what the pool did about it.
    inline int s6_merge_cascade(uint64_t seed, dst::Progress* prog, const std::string& wd) {
        (void)wd;
        using chronokv_page::PagePool;
        using chronokv_page::PAGE_SIZE;
        using chronokv_btree::BTree;
        PagePool pool(32ULL * 1024 * 1024);
        BTree tree(pool);

        constexpr int NKEYS = 900, NOWN = 2, BLOCK = 64, ROUNDS = 3;
        constexpr int PER = NKEYS / NOWN;      // 450 contiguous keys per owner
        constexpr int VALLEN = 40;             // ~64 entries/leaf => ~15 leaves
        constexpr int NSCAN = 12;
        const std::string lo = "k0000", hi = "k9999";
        auto key = [](int i) {
            char b[8]; snprintf(b, sizeof b, "k%04d", i); return std::string(b);
        };
        auto val = [](int i, int r) {
            std::string v = "c" + std::to_string(r) + ":" + std::to_string(i) + ":";
            v.resize(VALLEN, '#');
            return v;
        };
        auto legitimate = [&](const std::string& k, const std::string& v) {
            if (k.size() != 5 || k[0] != 'k') return false;
            const int i = atoi(k.c_str() + 1);
            if (i < 0 || i >= NKEYS || key(i) != k) return false;
            for (int r = 0; r <= ROUNDS; ++r) if (v == val(i, r)) return true;
            return false;
        };

        // Build phase (unarmed, single-threaded): a multi-level tree.
        for (int i = 0; i < NKEYS; ++i) tree.put(key(i), val(i, 0));
        const size_t depth_built = tree.depth();
        const size_t pages_built = pool.allocated() / PAGE_SIZE;
        if (depth_built < 2 || pages_built < 3) {
            fprintf(stderr, "dst S6: build phase produced depth=%zu pages=%zu — need a "
                            "multi-level tree for a cascade\n", depth_built, pages_built);
            return 19;
        }

        std::atomic<long> n_del{0}, n_del_miss{0}, n_ins{0}, n_throw{0};
        std::atomic<long> n_scans{0}, n_rows{0}, n_bad{0};
        dst::arm(seed, NOWN + 3, prog);
        std::vector<std::thread> owners;
        for (int t = 0; t < NOWN; ++t) owners.emplace_back([&, t] {
            dst::point("start");
            const int base = t * PER, end = base + PER;
            for (int r = 1; r <= ROUNDS; ++r) {
                // Final round: owner 0 leaves its half EMPTY (the cascade);
                // owner 1 refills, so the differential is non-trivial.
                const bool refill = !(r == ROUNDS && t == 0);
                for (int b = base; b < end; b += BLOCK) {
                    const int bend = (b + BLOCK < end) ? b + BLOCK : end;
                    for (int i = b; i < bend; ++i) {
                        dst::point("s6_del");
                        try {
                            if (tree.erase(key(i))) n_del.fetch_add(1, std::memory_order_relaxed);
                            else n_del_miss.fetch_add(1, std::memory_order_relaxed);
                        } catch (...) { n_throw.fetch_add(1, std::memory_order_relaxed); }
                    }
                    dst::point("s6_drained");
                    if (refill) {
                        for (int i = b; i < bend; ++i) {
                            dst::point("s6_ins");
                            try {
                                if (tree.put(key(i), val(i, r))) n_ins.fetch_add(1, std::memory_order_relaxed);
                            } catch (...) { n_throw.fetch_add(1, std::memory_order_relaxed); }
                        }
                    }
                }
            }
            dst::thread_done();
        });
        auto scan_loop = [&](bool narrow) {
            dst::point("start");
            for (int n = 0; n < NSCAN; ++n) {
                dst::point("s6_scan");
                std::string slo = lo, shi = hi;
                if (narrow) {
                    const int a = (n * 137) % NKEYS;
                    const int b = (a + 96 < NKEYS) ? a + 96 : NKEYS - 1;
                    slo = key(a); shi = key(b);
                }
                std::vector<std::pair<std::string, std::string>> rs;
                try { rs = tree.range_scan(slo, shi); }
                catch (...) { n_throw.fetch_add(1, std::memory_order_relaxed); break; }
                n_scans.fetch_add(1, std::memory_order_relaxed);
                for (auto& [k, v] : rs) {
                    n_rows.fetch_add(1, std::memory_order_relaxed);
                    if (!legitimate(k, v)) n_bad.fetch_add(1, std::memory_order_relaxed);
                    if (k < slo || k > shi) n_bad.fetch_add(1, std::memory_order_relaxed);
                }
            }
            dst::thread_done();
        };
        std::thread sc1(scan_loop, false), sc2(scan_loop, false), sc3(scan_loop, true);
        for (auto& t : owners) t.join();
        sc1.join(); sc2.join(); sc3.join();
        dst::disarm();

        if (n_bad.load()) {
            fprintf(stderr, "dst S6: %ld illegitimate observations (foreign/garbage value or "
                            "key outside the scanned range)\n", n_bad.load());
            return 9;
        }
        if (n_throw.load()) {
            fprintf(stderr, "dst S6: %ld unexpected exceptions\n", n_throw.load());
            return 10;
        }
        if (n_del_miss.load()) {
            fprintf(stderr, "dst S6: %ld erases missed a key present in the built tree\n",
                    n_del_miss.load());
            return 11;
        }
        if (n_del.load() < NKEYS || n_ins.load() < PER || n_scans.load() != 3 * NSCAN ||
            n_rows.load() == 0) {
            fprintf(stderr, "dst S6: VACUOUS workload (del=%ld ins=%ld scans=%ld rows=%ld)\n",
                    n_del.load(), n_ins.load(), n_scans.load(), n_rows.load());
            return 12;
        }
        // Exact differential: owner 1's half present at val(i,ROUNDS), owner
        // 0's half absent.
        std::map<std::string, std::string> expect;
        for (int i = PER; i < NKEYS; ++i) expect[key(i)] = val(i, ROUNDS);
        std::vector<std::pair<std::string, std::string>> rs;
        try { rs = tree.range_scan(lo, hi); }
        catch (const std::exception& e) {
            fprintf(stderr, "dst S6: quiesced range_scan threw: %s\n", e.what());
            return 13;
        }
        if (rs.size() != expect.size()) {
            fprintf(stderr, "dst S6: quiesced scan returned %zu rows, differential oracle "
                            "expects %zu\n", rs.size(), expect.size());
            return 13;
        }
        for (size_t j = 0; j < rs.size(); ++j) {
            if (j > 0 && !(rs[j - 1].first < rs[j].first)) {
                fprintf(stderr, "dst S6: quiesced scan out of order / duplicated at row %zu\n", j);
                return 14;
            }
            auto it = expect.find(rs[j].first);
            if (it == expect.end() || it->second != rs[j].second) {
                fprintf(stderr, "dst S6: quiesced row %zu = (%s,%.12s) disagrees with the "
                                "differential oracle\n", j, rs[j].first.c_str(),
                        rs[j].second.c_str());
                return 13;
            }
        }
        for (int i = 0; i < NKEYS; ++i) {
            std::string got;
            const bool found = tree.get(key(i), &got);
            const bool want = (i >= PER);
            if (found != want || (want && got != val(i, ROUNDS))) {
                fprintf(stderr, "dst S6: point read %s: found=%d want=%d value=%.12s\n",
                        key(i).c_str(), (int)found, (int)want, got.c_str());
                return 15;
            }
        }
        // The maximal cascade, deterministically: drain the surviving half so
        // the tree is EMPTY. Post-M4 this is every leaf merged, every
        // interior separator deleted and the root collapsed; today it is an
        // empty key set on a tree that still holds every page it ever
        // allocated — the number P1 is about, recorded below.
        for (int i = PER; i < NKEYS; ++i) {
            if (!tree.erase(key(i))) {
                fprintf(stderr, "dst S6: final drain missed %s\n", key(i).c_str());
                return 11;
            }
        }
        if (tree.size() != 0) {
            fprintf(stderr, "dst S6: fully drained tree reports size=%zu\n", tree.size());
            return 15;
        }
        {
            std::vector<std::pair<std::string, std::string>> empty;
            try { empty = tree.range_scan(lo, hi); }
            catch (const std::exception& e) {
                fprintf(stderr, "dst S6: post-drain range_scan threw: %s\n", e.what());
                return 13;
            }
            if (!empty.empty()) {
                fprintf(stderr, "dst S6: post-drain scan returned %zu rows (expected 0)\n",
                        empty.size());
                return 15;
            }
        }
        const size_t pages = pool.allocated() / PAGE_SIZE;
        if (pool.live_count() + pool.free_count() != pages) {
            fprintf(stderr, "dst S6: pool accounting broken: live=%zu free=%zu allocated=%zu\n",
                    pool.live_count(), pool.free_count(), pages);
            return 16;
        }
        if (tree.hp_in_use_for_test() != 0 || tree.hp_slot_count_for_test() > 16) {
            fprintf(stderr, "dst S6: HP registry not quiesced/bounded: in_use=%zu slots=%zu\n",
                    tree.hp_in_use_for_test(), tree.hp_slot_count_for_test());
            return 17;
        }
        if (!census_gate("S6", prog, {"tree_leaf_latch_gap", "tree_cursor_leaf_switch"}))
            return 20;
        census_report("S6", prog, design_windows_m4());
        if (getenv("CKV_DST_REPORT")) {
            printf("      [S6] witnesses: del=%ld ins=%ld scans=%ld rows=%ld\n",
                   n_del.load(), n_ins.load(), n_scans.load(), n_rows.load());
            printf("      [S6] pool: built(depth=%zu pages=%zu) -> empty-tree(depth=%zu "
                   "high_water_bytes=%zu pages=%zu live=%zu free=%zu) size=%zu\n"
                   "             RECORDED, not asserted: today an emptied tree retains every "
                   "page (README limitation #1). M3/M4 invariant P1 turns this into a gate — "
                   "depth back to 1 and live pages bounded by the surviving key set.\n",
                   depth_built, pages_built, tree.depth(), pool.allocated(), pages,
                   pool.live_count(), pool.free_count(), tree.size());
        }
        return 0;
    }

    // S7 — reclamation / retirement / reuse (M3 design-first, engine-level).
    //
    // The epoch reclaimer is REAL code today: version nodes retired by an
    // overwrite are held in retired_nodes_ tagged with the retirement epoch,
    // and reclaim_retired() frees exactly those strictly older than the
    // oldest live pin. M3 retires PAGES through that same reclaimer (or
    // through generation-tagged ids — the HP4 decision), so its admission
    // rule is the design's and this scenario pins it against the running
    // engine now:
    //   phase 1 (armed) — version churn + synchronous GC passes + a
    //           concurrent scanner with a written-value legitimacy oracle, so
    //           the retirement path is exercised under the seeded schedule
    //           (gc_pass_begin / gc_epoch_advance / gc_reclaim_begin /
    //           scan_guard_acquired are census-gated);
    //   phase 2 (disarmed, deterministic) — the admission rule itself:
    //           drain to zero pending, pin a snapshot with a stream reader,
    //           retire 24 more versions under the pin, run passes, and
    //           require that (a) something is still PENDING (the pin held
    //           reclamation back), (b) oldest_active_pin_epoch <=
    //           reclaim_epoch, (c) the pinned reader still resolves the
    //           value its snapshot needs — the node it depends on was not
    //           freed from under it, (d) the live chain is intact at a fresh
    //           snapshot, and (e) once the pin is released the held-back
    //           nodes are actually reclaimed.
    // A reclaimer that ignores pins fails (a) deterministically and (c) as a
    // use-after-free; that is M3's page-retirement defect class, caught
    // before the page path exists.
    inline int s7_reclaim_retire(uint64_t seed, dst::Progress* prog, const std::string& wd) {
        using chronokv::Options;
        using chronokv::Database;
        using chronokv::Status;
        Options o;
        o.wal_dir = wd;
        o.auto_start_gc = false;                 // synchronous passes only (replay contract)
        o.durability = DurabilityMode::Async;    // no fsync stalls inside the schedule
        o.page_pool_bytes = 16ULL * 1024 * 1024;
        auto db = Database::open(o);
        auto eng = db.engine_for_test();

        constexpr int NW = 2, NKEYS = 4, ROUNDS = 20, NSCAN = 20;
        const std::string lo = "g0", hi = "g9";
        std::atomic<long> seq{0}, n_commit{0}, n_scans{0}, n_rows{0}, n_bad{0}, n_throw{0};
        dst::arm(seed, NW + 2, prog);
        std::mutex legit_mu;
        std::map<std::string, std::set<std::string>> legit;
        std::vector<std::thread> ws;
        for (int t = 0; t < NW; ++t) ws.emplace_back([&] {
            dst::point("start");
            for (int n = 0; n < ROUNDS; ++n) {
                dst::point("s7_w");
                const long v = seq.fetch_add(1, std::memory_order_relaxed) + 1;
                const std::string k = "g" + std::to_string(n % NKEYS);
                const std::string val = "v" + std::to_string(v);
                {
                    std::lock_guard<std::mutex> g(legit_mu);
                    legit[k].insert(val);
                }
                try {
                    if (db.put(k, val) == Status::OK)
                        n_commit.fetch_add(1, std::memory_order_relaxed);
                } catch (...) { n_throw.fetch_add(1, std::memory_order_relaxed); }
            }
            dst::thread_done();
        });
        std::thread scanner([&] {
            dst::point("start");
            for (int n = 0; n < NSCAN; ++n) {
                dst::point("s7_scan");
                std::vector<std::pair<std::string, std::string>> rs;
                try { rs = db.range_scan(lo, hi); }
                catch (...) { n_throw.fetch_add(1, std::memory_order_relaxed); break; }
                n_scans.fetch_add(1, std::memory_order_relaxed);
                for (auto& [k, v] : rs) {
                    n_rows.fetch_add(1, std::memory_order_relaxed);
                    std::lock_guard<std::mutex> g(legit_mu);
                    auto it = legit.find(k);
                    if (it == legit.end() || !it->second.count(v))
                        n_bad.fetch_add(1, std::memory_order_relaxed);
                }
            }
            dst::thread_done();
        });
        std::thread gct([&] {
            dst::point("start");
            for (int n = 0; n < ROUNDS * 2; ++n) {
                dst::point("s7_gc");
                try { eng->gc_pass_for_test(); }
                catch (...) { n_throw.fetch_add(1, std::memory_order_relaxed); }
            }
            dst::thread_done();
        });
        for (auto& t : ws) t.join();
        scanner.join();
        gct.join();
        dst::disarm();

        if (n_bad.load()) {
            fprintf(stderr, "dst S7: %ld scan anomalies (value never written to that key — "
                            "reclaimed-under-reader class)\n", n_bad.load());
            return 9;
        }
        if (n_throw.load()) {
            fprintf(stderr, "dst S7: %ld unexpected exceptions\n", n_throw.load());
            return 10;
        }
        auto g = db.gc_stats();
        // Non-vacuity: the retirement machinery must actually have run.
        if (n_commit.load() != NW * ROUNDS || n_scans.load() != NSCAN || n_rows.load() == 0) {
            fprintf(stderr, "dst S7: VACUOUS workload (commits=%ld/%d scans=%ld/%d rows=%ld)\n",
                    n_commit.load(), NW * ROUNDS, n_scans.load(), NSCAN, n_rows.load());
            return 12;
        }
        if (g.retired == 0 || g.reclaimed == 0 || g.passes == 0) {
            fprintf(stderr, "dst S7: VACUOUS reclamation (retired=%llu reclaimed=%llu "
                            "passes=%llu)\n", (unsigned long long)g.retired,
                    (unsigned long long)g.reclaimed, (unsigned long long)g.passes);
            return 12;
        }
        if (!census_gate("S7", prog, {"gc_pass_begin", "gc_epoch_advance", "gc_reclaim_begin",
                                      "scan_guard_acquired"}))
            return 20;

        // ---- phase 2: the admission rule, deterministically ----
        auto drain = [&]() {
            for (int i = 0; i < 64; ++i) {
                eng->gc_pass_for_test();
                if (db.gc_stats().retired_pending == 0) break;
            }
            return db.gc_stats();
        };
        const auto g0 = drain();
        if (g0.retired_pending != 0) {
            fprintf(stderr, "dst S7: baseline drain left %llu retirements pending with no "
                            "reader pinned\n", (unsigned long long)g0.retired_pending);
            return 21;
        }
        const std::string pk = "g0", pval = "PIN0";
        if (db.put(pk, pval) != Status::OK) {
            fprintf(stderr, "dst S7: cannot seed the pinned key\n");
            return 21;
        }
        {
            std::lock_guard<std::mutex> lg(legit_mu);
            legit[pk].insert(pval);
        }
        if (db.get(pk) != std::optional<std::string>(pval)) {
            fprintf(stderr, "dst S7: seeded value not visible before the pin (setup)\n");
            return 21;
        }
        eng->gc_pass_for_test();
        const uint64_t reclaimed_at_pin = db.gc_stats().reclaimed;
        {
            // The stream holds a SnapshotGuard for its whole lifetime: a real
            // reader-slot pin on the current reclaim epoch.
            Database::RangeScanStream pin(db, lo, hi);
            constexpr int CHURN = 24;
            for (int i = 1; i <= CHURN; ++i) {
                const std::string v = "PIN" + std::to_string(i);
                if (db.put(pk, v) != Status::OK) {
                    fprintf(stderr, "dst S7: churn put %d failed\n", i);
                    return 21;
                }
                {
                    std::lock_guard<std::mutex> lg(legit_mu);
                    legit[pk].insert(v);
                }
            }
            for (int pass = 0; pass < 8; ++pass) eng->gc_pass_for_test();
            const auto g1 = db.gc_stats();
            // (a) the pin held reclamation back
            if (g1.retired_pending == 0) {
                fprintf(stderr, "dst S7: %d versions retired under a live pin were ALL "
                                "reclaimed (retired_pending=0, reclaimed %llu -> %llu) — the "
                                "reclaimer ignored the pin\n", CHURN,
                        (unsigned long long)reclaimed_at_pin, (unsigned long long)g1.reclaimed);
                return 22;
            }
            // (b) the pin is the oldest thing in the system
            if (!(g1.oldest_active_pin_epoch <= g1.reclaim_epoch)) {
                fprintf(stderr, "dst S7: oldest_active_pin_epoch=%llu > reclaim_epoch=%llu\n",
                        (unsigned long long)g1.oldest_active_pin_epoch,
                        (unsigned long long)g1.reclaim_epoch);
                return 23;
            }
            // (c) the pinned snapshot still resolves the value it needs
            bool saw_pin = false;
            while (pin.has_next()) {
                auto row = pin.next();
                if (row.first == pk) {
                    saw_pin = true;
                    if (row.second != pval) {
                        fprintf(stderr, "dst S7: pinned reader saw %s = %.12s, its snapshot "
                                        "requires %.12s (version reclaimed or reused under "
                                        "the pin)\n", pk.c_str(), row.second.c_str(),
                                pval.c_str());
                        return 24;
                    }
                }
                std::lock_guard<std::mutex> lg(legit_mu);
                auto it = legit.find(row.first);
                if (it == legit.end() || !it->second.count(row.second)) {
                    fprintf(stderr, "dst S7: pinned reader saw illegitimate (%s,%.12s)\n",
                            row.first.c_str(), row.second.c_str());
                    return 24;
                }
            }
            if (!saw_pin) {
                fprintf(stderr, "dst S7: pinned scan never reached %s\n", pk.c_str());
                return 24;
            }
        }   // pin released here
        // (d) the live chain is intact at a fresh snapshot
        if (db.get(pk) != std::optional<std::string>("PIN24")) {
            fprintf(stderr, "dst S7: post-pin read of %s = %.12s (expected PIN24) — the live "
                            "chain was over-trimmed\n", pk.c_str(),
                    db.get(pk) ? db.get(pk)->c_str() : "<absent>");
            return 25;
        }
        // (e) reclamation resumes once the pin is gone
        const auto g2 = drain();
        if (g2.retired_pending != 0) {
            fprintf(stderr, "dst S7: %llu retirements still pending after the pin was "
                            "released\n", (unsigned long long)g2.retired_pending);
            return 26;
        }
        if (!(g2.reclaimed > reclaimed_at_pin)) {
            fprintf(stderr, "dst S7: reclamation did not resume after unpin (reclaimed %llu -> "
                            "%llu)\n", (unsigned long long)reclaimed_at_pin,
                    (unsigned long long)g2.reclaimed);
            return 26;
        }
        census_report("S7", prog, design_windows_m3());
        if (getenv("CKV_DST_REPORT")) {
            printf("      [S7] witnesses: commits=%ld scans=%ld rows=%ld\n", n_commit.load(),
                   n_scans.load(), n_rows.load());
            printf("      [S7] gc: created=%llu retired=%llu reclaimed=%llu passes=%llu "
                   "reclaim_epoch=%llu  pin-blocked pending=%llu then drained to %llu\n",
                   (unsigned long long)g.created, (unsigned long long)g.retired,
                   (unsigned long long)g2.reclaimed, (unsigned long long)g2.passes,
                   (unsigned long long)g2.reclaim_epoch,
                   (unsigned long long)db.gc_stats().retired_pending,
                   (unsigned long long)g2.retired_pending);
        }
        try { db.close(); } catch (...) {}
        return 0;
    }
